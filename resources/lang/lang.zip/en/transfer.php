<?php

return [
	'title' => 'Point Transfer',
	'subTitle' => 'Register, promotion, or cash point transfer.',
	'transfer' => 'Transfer Point',
	'amount' => 'Amount',
	'amountNotice' => 'Divisible by 10.',
	'target' => 'Transfer to',
	'targetNotice' => 'Username, CASE SENSITIVE',
	'security' => 'Security Password'
];
