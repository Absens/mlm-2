<?php

return [
	'loginSuccess'		=>	'Login success.',
    'registerSuccess'   =>  'Member register success.',
    'upgradeSuccess'	=>	'Package upgrade/renew success',
    'transferSuccess'	=>	'Point transfer success.',
    'sharesBuySuccess'	=>	'Shares purchase successful.',
    'sharesSellSuccess'	=>	'Shares sales successful.',
    'withdrawSuccess'	=>	'Withdraw successful.',
    'accountUpdateSuccess'	=>	'Account updated'
];
