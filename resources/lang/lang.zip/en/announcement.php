<?php

return [
    'title' => 'All Announcements',
    'listDate' => 'Created Date',
    'listTitle' => 'Title',
    'listAction' => 'Action'
];
