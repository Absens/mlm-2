<?php

return [
	'title' => 'Registration History',
	'subTitle' => 'Your direct members registration history.',
	'join' => 'Join Date',
	'username' => 'Username',
	'package' => 'Package',
	'action' => 'Action'
];
