<?php

return [
	'title' => 'Withdraw Statement',
	'subTitle' => 'Your withdraw status.',
	'create' => 'Created Date',
	'amount' => 'Amount',
	'status' => 'Status'
];
