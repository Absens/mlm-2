<?php

return [
	'title' => 'Unilevel Hierarchy',
	'subTitle' => 'Unilevel (Direct Member) Network. Empty means no direct member.',
	'member' => 'Member ID',
	'secret' => 'Security Password',
	'notice' => 'Please input ID first.',
];
