<?php

return [
	'title' => '推薦人架構',
	'subTitle' => '推薦人架構， 空白為不存在直接推薦人。',
	'member' => '賬號',
	'secret' => '安全密碼',
	'notice' => '請先輸入賬戶名。',
];
