<?php

return [
	'title' => '培育人架構',
	'subTitle' => '您的培育人架構。 (左) = 左區, (右) = 右區',
	'member' => '會員帳號',
	'secret' => '安全密碼',
	'notice' => '請先輸入賬戶名。',
	'upline' => '往上升1級',
	'top' => '回到頂部',
    'register' => '註冊新會員',
    'modal.title' => '會員資訊',
    'modal.info' => '會員信息',
    'modal.id' => '賬戶名',
    'modal.join' => '加入日期',
    'modal.package' => '配套信息',
    'modal.sponsor' => '推薦人',
    'modal.info2' => '積分報告',
    'modal.left' => '左區積分',
    'modal.right' => '右區積分',
    'modal.carry' => '昨日結餘',
    'modal.today' => '今日成交量',
    'modal.total' => '累計銷售'
];
