<?php

return [
	'front'	=>	'首頁',
	'dashboard'	=>	'會員專區',
	'settingsPersonal' => '個人資料',
	'settingsBank' => '銀行資料',
	'hierarchy' => '會員架構',
	'register' => '註冊新會員',
	'registerHistory' => '會員註冊記錄',
	'registerSuccess' => '已成功註冊該會員',
	'upgrade' => '升級/重購配套',
	'binary' => '培育人架構',
	'unilevel' => '推薦人架構',
	'sharesMarket' => 'MD積分交易市場',
	'sharesLock' => 'MD積分（鎖）報告',
	'sharesStatement' => 'MD積分交易記錄',
	'withdraw' => '提現申請',
	'withdrawStatement' => '提現報表',
	'transfer' => '積分交易平台',
	'bonusStatement' => '獎勵報表',
	'summary' => '財務總結報表',
	'announcementList' => '公司公告',
	'groupPending' => '待發見點獎勵'
];
