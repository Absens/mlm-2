<?php

return [
	'title' => '積分交易中心',
	'subTitle' => '註冊積分, 優惠積分, 或 現金積分轉移',
	'transfer' => '積分轉移',
	'amount' => '數額',
	'amountNotice' => '必須是10的倍數。',
	'target' => '轉移至',
	'targetNotice' => '請區分大小寫',
	'security' => '安全密碼'
];
