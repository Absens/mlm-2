<?php

return [
	'loginSuccess'		=>	'成功登錄。',
    'registerSuccess'   =>  '成功註冊會員。',
    'upgradeSuccess'	=>	'配套升級/重購成功。',
    'transferSuccess'	=>	'積分轉移成功。',
    'sharesBuySuccess'	=>	'MD積分買入成功。.',
    'sharesSellSuccess'	=>	'MD積分賣出成功。',
    'withdrawSuccess'	=>	'提現申請成功。',
    'accountUpdateSuccess'	=>	'會員資料已更新。'
];
