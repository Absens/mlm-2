<?php

return [
    'Cambodia' => '柬埔寨',
    'China' => '中國',
    'Indonesia' => '印尼',
    'Malaysia' => '馬來西亞',
    'Philippines' => '菲律賓',
    'Singapore' => '新加坡',
    'Thailand' => '泰國',
    'Taiwan' => '台灣',
    'Vietnam' => '越南',
    'selected' => '選定國家'
];
