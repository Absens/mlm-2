<?php

return [
	'qTitle' =>	'快捷按鍵',
	'qCheckHierarchy' => '查詢架構',
	'qAddMember' =>	'註冊新會員',
	'qWithdraw' => '提現申請',
	'qShares' => 'MD積分交易專區',
	'spMissing' => '<h4>安全密碼不存在！</h4> <strong>您尚未設置您的安全密碼</strong> 您必須設置安全密碼才能進行該交易。', // don't remove the <h4></h4> and <strong></strong>
	'spMissingLink' => '設置安全密碼',
	'rateTitle' => '兌換率',
	'rateSub' => '兌換率報表',
	'rateCountry' => '國家',
	'rateCurrency' => '貨幣',
	'rateBuy' => '買入',
	'rateSell' => '賣出'
];
