<?php

return [
'title'	=>	'登入會員專區',
'subtitle' => '歡迎登入 | 會員專區',
'username' => '賬號',
'password' => '密碼',
'remember' => '記得密碼'
];