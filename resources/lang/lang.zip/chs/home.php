<?php

return [
	'qTitle' =>	'快捷按键',
	'qCheckHierarchy' => '查询架构',
	'qAddMember' =>	'注册新会员',
	'qWithdraw' => '提现申请',
	'qShares' => 'MD积分交易专区',
	'spMissing' => '<h4>安全密码不存在！</h4> <strong>您尚未设置您的安全密码</strong> 您必须设置安全密码才能进行该交易。', // don't remove the <h4></h4> and <strong></strong>
	'spMissingLink' => '设置安全密码',
	'rateTitle' => '兑换率',
	'rateSub' => '兑换率报表',
	'rateCountry' => '国家',
	'rateCurrency' => '货币',
	'rateBuy' => '买入',
	'rateSell' => '卖出'
];
