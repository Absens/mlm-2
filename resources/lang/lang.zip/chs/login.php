<?php

return [
'title'	=>	'登入会员专区',
'subtitle' => '欢迎登入 | 会员专区',
'username' => '账号',
'password' => '密码',
'remember' => '记得密码'
];