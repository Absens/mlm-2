<?php

return [
	'title' => '提现记录',
	'subTitle' => '提现记录',
	'create' => '创立日期',
	'amount' => '数额',
	'status' => '状态'
];
