<?php

return [
	'title' => 'MD积分（锁）报表',
	'subTitle' => 'MD积分（锁）.',
	'create' => '创立日期',
	'active' => '开通日期',
	'amount' => '数额',
	'process' => '当前状态'
];
