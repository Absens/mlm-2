<?php

return [
    'Cambodia' => '柬埔寨',
    'China' => '中国',
    'Indonesia' => '印尼',
    'Malaysia' => '马来西亚',
    'Philippines' => '菲律宾',
    'Singapore' => '新加坡',
    'Thailand' => '泰国',
    'Taiwan' => '台湾',
    'Vietnam' => '越南',
    'selected' => '选定国家'
];
