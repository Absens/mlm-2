<?php

return [
	'front'	=>	'首页',
	'dashboard'	=>	'会员专区',
	'settingsPersonal' => '个人资料',
	'settingsBank' => '银行资料',
	'hierarchy' => '会员架构',
	'register' => '注册新会员',
	'registerHistory' => '会员注册记录',
	'registerSuccess' => '已成功注册该会员',
	'upgrade' => '升级/重购配套',
	'binary' => '培育人架构',
	'unilevel' => '推荐人架构',
	'sharesMarket' => 'MD积分交易市场',
	'sharesLock' => 'MD积分（锁）报告',
	'sharesStatement' => 'MD积分交易记录',
	'withdraw' => '提现申请',
	'withdrawStatement' => '提现报表',
	'transfer' => '积分交易平台',
	'bonusStatement' => '奖励报表',
	'summary' => '财务总结报表',
	'announcementList' => '公司公告',
	'groupPending' => '待发见点奖励'
];
