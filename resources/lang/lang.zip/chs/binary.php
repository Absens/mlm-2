<?php

return [
	'title' => '培育人架构',
	'subTitle' => '您的培育人架构。 (左) = 左区, (右) = 右区',
	'member' => '会员账号',
	'secret' => '安全密码',
	'notice' => '请先输入账户名。',
	'upline' => '往上升1级',
	'top' => '回到顶部',
    'register' => '注册新会员',
    'modal.title' => '会员资讯',
    'modal.info' => '会员信息',
    'modal.id' => '账户名',
    'modal.join' => '加入日期',
    'modal.package' => '配套信息',
    'modal.sponsor' => '推荐人',
    'modal.info2' => '积分报告',
    'modal.left' => '左区积分',
    'modal.right' => '右区积分',
    'modal.carry' => '昨日结余',
    'modal.today' => '今日成交量',
    'modal.total' => '累计销售'
];
